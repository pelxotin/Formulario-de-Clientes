import { Component } from '@angular/core';
import { Cliente } from './cliente';
import {  FormsModule } from '@angular/forms';
import { ClienteService } from '../services/cliente.service';


@Component({
  selector: 'app-cadastro',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './cadastro.component.html',
  styleUrl: './cadastro.component.css',
  providers: [ClienteService]
})
export class CadastroComponent {
  cliente: Cliente = Cliente.novoCliente();

  constructor(private service: ClienteService) {}

  salvarCliente() {
    this.service.salvarCliente(this.cliente);
    this.service.limparCliente(this.cliente);
  }
}
