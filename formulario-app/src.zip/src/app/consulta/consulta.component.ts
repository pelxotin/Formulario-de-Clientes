import { Component,OnInit } from '@angular/core';
import { Cliente } from '../cadastro/cliente';
import { ClienteService } from '../services/cliente.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-consulta',
  standalone: true,
  imports: [FormsModule, CommonModule],
  providers: [ClienteService],
  templateUrl: './consulta.component.html',
  styleUrl: './consulta.component.css'
})
export class ConsultaComponent {

  nomeBusca: string = '';
  listaClientes: Cliente[] = [];

  constructor(private service: ClienteService) { }

  ngOnInit() {
    this.listaClientes = this.service.pesquisarClientes('');
  }

  pesquisarCliente() {
    console.log(this.nomeBusca);
    this.listaClientes = this.service.pesquisarClientes(this.nomeBusca);
  }
}



